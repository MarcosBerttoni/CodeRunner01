package excepciones;

public class RangoOpcionException extends Exception {

	public RangoOpcionException(String mensaje) {
		super(mensaje);
	}
	
	

}
